from django.apps import AppConfig


class MymapConfig(AppConfig):
    name = 'mymap'
